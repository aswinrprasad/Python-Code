food_kinds=["Rotti","Tandoori Chicken","Chicken Biriyani","Mint Lime","Chicken 65","Veg Fried Rice","Cold Coffee"]
print food_kinds

fav_food_kinds=food_kinds[1]+", "+food_kinds[3]+", "+food_kinds[4]+", "+food_kinds[6]
print fav_food_kinds
